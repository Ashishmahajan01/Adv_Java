const HomeComponent=(props)=>{
    return(
        <div>HomeComponent component</div>
    )

}

export default HomeComponent;