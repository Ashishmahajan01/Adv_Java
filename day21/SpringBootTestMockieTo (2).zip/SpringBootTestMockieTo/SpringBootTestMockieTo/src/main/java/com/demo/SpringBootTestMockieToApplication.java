package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTestMockieToApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTestMockieToApplication.class, args);
	}

}
